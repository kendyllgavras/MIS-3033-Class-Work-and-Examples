# MIS-3033-Class-Work-and-Examples
class work and examples not for a grade
