﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChuckNorris
{
    class categories
    {



    }
    public class QuoteSelected
    {
        string quote { get; set; }

    }
}
